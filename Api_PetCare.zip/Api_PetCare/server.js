const express = require('express');
const cors = require('cors');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(express.json());

const FILE = 'vetdata.json';

// Crear archivo si no existe
if (!fs.existsSync(FILE)) {
    const initialData = {
        owners: [],
        pets: [],
        appointments: []
    };
    fs.writeFileSync(FILE, JSON.stringify(initialData, null, 2));
}

// Leer y escribir datos
const readData = () => JSON.parse(fs.readFileSync(FILE, 'utf8'));
const writeData = (data) => fs.writeFileSync(FILE, JSON.stringify(data, null, 2));

// Ruta de bienvenida
app.get('/', (req, res) => {
    res.json({ message: "🐶 Veterinaria API - ¡TODO FUNCIONA PERFECTO!" });
});

// ==================== DUEÑOS ====================

// Crear dueño
app.post('/owners', (req, res) => {
    const { name, fLastName, sLastName, email, password, phone, address } = req.body;
    
    if (!name || !fLastName || !email || !password || !phone) {
        return res.status(400).json({ error: "Faltan campos obligatorios" });
    }

    const data = readData();
    const newOwner = {
        id: uuidv4(),
        name, fLastName, sLastName, email, password, phone, address
    };
    
    data.owners.push(newOwner);
    writeData(data);
    
    // No devolvemos la contraseña por seguridad
    const { password: _, ...ownerWithoutPass } = newOwner;
    res.status(201).json(ownerWithoutPass);
});

// Obtener todos los dueños
app.get('/owners', (req, res) => {
    const data = readData();
    const ownersWithoutPass = data.owners.map(({ password, ...owner }) => owner);
    res.json(ownersWithoutPass);
});

// Editar dueño
app.put('/owners/:id', (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    const data = readData();
    
    const ownerIndex = data.owners.findIndex(o => o.id === id);
    if (ownerIndex === -1) return res.status(404).json({ error: "Dueño no encontrado" });

    data.owners[ownerIndex] = { ...data.owners[ownerIndex], ...updates };
    writeData(data);
    
    const { password: _, ...updatedOwner } = data.owners[ownerIndex];
    res.json(updatedOwner);
});

// Eliminar dueño
app.delete('/owners/:id', (req, res) => {
    const { id } = req.params;
    const data = readData();
    
    data.owners = data.owners.filter(o => o.id !== id);
    // También eliminamos sus mascotas y citas (opcional)
    data.pets = data.pets.filter(p => p.ownerId !== id);
    data.appointments = data.appointments.filter(a => a.ownerId !== id);
    
    writeData(data);
    res.json({ message: "Dueño y sus datos eliminados" });
});
// ==================== LOGIN ====================

app.post('/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: "Email y contraseña son obligatorios" });
    }

    const data = readData();
    const owner = data.owners.find(o => o.email === email && o.password === password);

    if (!owner) {
        return res.status(401).json({ error: "Credenciales inválidas" });
    }

    const { password: _, ...ownerWithoutPass } = owner;
    res.json(ownerWithoutPass);
});


// ==================== MASCOTAS ====================

// Crear mascota
app.post('/pets', (req, res) => {
    const { petName, breed, gender, age, weight, ownerId, notes } = req.body;
    
    if (!petName || !breed || !ownerId) {
        return res.status(400).json({ error: "Faltan datos de la mascota" });
    }

    const data = readData();
    if (!data.owners.find(o => o.id === ownerId)) {
        return res.status(404).json({ error: "Dueño no encontrado" });
    }

    const newPet = {
        id: uuidv4(),
        petName,
        breed,
        gender,
        age: parseInt(age) || 0,
        weight: parseFloat(weight) || 0.0,
        ownerId,
        notes: notes || "",
        photo: null // puedes mandar base64 después
    };

    data.pets.push(newPet);
    writeData(data);
    res.status(201).json(newPet);
});

// Obtener todas las mascotas
app.get('/pets', (req, res) => {
    const data = readData();
    res.json(data.pets);
});

// Editar mascota
app.put('/pets/:id', (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    const data = readData();
    
    const petIndex = data.pets.findIndex(p => p.id === id);
    if (petIndex === -1) return res.status(404).json({ error: "Mascota no encontrada" });

    data.pets[petIndex] = { ...data.pets[petIndex], ...updates };
    writeData(data);
    res.json(data.pets[petIndex]);
});

// Eliminar mascota
app.delete('/pets/:id', (req, res) => {
    const { id } = req.params;
    const data = readData();
    
    data.pets = data.pets.filter(p => p.id !== id);
    data.appointments = data.appointments.filter(a => a.petId !== id);
    
    writeData(data);
    res.json({ message: "Mascota eliminada" });
});

// ==================== CITAS ====================

// Crear cita
app.post('/appointments', (req, res) => {
    const { petId, serviceType, date, hour, notes } = req.body;
    
    if (!petId || !serviceType || !date || !hour) {
        return res.status(400).json({ error: "Faltan datos de la cita" });
    }

    const data = readData();
    if (!data.pets.find(p => p.id === petId)) {
        return res.status(404).json({ error: "Mascota no encontrada" });
    }

    const newAppointment = {
        id: uuidv4(),
        petId,
        serviceType,
        date,
        hour,
        notes: notes || "",
        status: "Pendiente"
    };

    data.appointments.push(newAppointment);
    writeData(data);
    res.status(201).json(newAppointment);
});

// Obtener todas las citas
app.get('/appointments', (req, res) => {
    const data = readData();
    res.json(data.appointments.sort((a, b) => new Date(b.date) - new Date(a.date)));
});

// Actualizar estado de cita
app.put('/appointments/:id', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const data = readData();
    
    const appointment = data.appointments.find(a => a.id === id);
    if (!appointment) return res.status(404).json({ error: "Cita no encontrada" });

    appointment.status = status || appointment.status;
    writeData(data);
    res.json(appointment);
});

// Eliminar cita
app.delete('/appointments/:id', (req, res) => {
    const { id } = req.params;
    const data = readData();
    
    data.appointments = data.appointments.filter(a => a.id !== id);
    writeData(data);
    res.json({ message: "Cita eliminada" });
});

// Iniciar servidor
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Veterinaria API corriendo en http://localhost:${PORT}`);
});
